// Implements a dictionary's functionalionty
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;

// TODO: Choose number of buckets in hash table
const unsigned int N = 27;
unsigned int wordCount = 0;

// Hash table
node *table[N];

bool isPrime(n) {
    if (n<2) return false;
    for (int i = 2; i < (int) floor(sqrt(n)); i++) {
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    int count = 0;
    int numPrimes = 0;
    for (int i = 0; i < LENGTH-1; i++) {
        if (!isPrime(i)) {
            continue;
        }
        if (i >= strlen(word)-1) {
            break;
        }
        count += toupper(word[i]) - 'A';
        numPrimes++;
    }
    // int firstLetter = toupper(word[0]) - 'A';
    // int lastLetter = toupper(word[strlen(word)-1]) - 'A';
    // return (unsigned int) round((firstLetter + lastLetter)/strlen(word)) % N;
    return (unsigned int) round(count/(numPrimes ? numPrimes : 1)) % N;
}

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    int hashed = hash(word);
    char *new_word = malloc(LENGTH+1);

    for (int i = 0; i < strlen(word); i++) {
        new_word[i] = tolower(word[i]);
    }

    new_word[strlen(word)] = '\0';

    node *ptr = table[hashed];
    while(ptr != NULL) {
        if(strcmp(ptr->word, new_word)==0){
            free(new_word);
            return true;
        }
        ptr = ptr->next;
    }
    free(new_word);
    return false;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    FILE *dict = fopen(dictionary, "r");
    node *new_node = NULL;
    if (dict == NULL) {
        return false;
    }
    char word[LENGTH + 1];
    while (fscanf(dict, "%s", word) != EOF)
    {
        wordCount++;
        new_node = malloc(sizeof(node));
        if (new_node == NULL) {
            return false;
        }
        new_node->next = NULL;
        unsigned int wordHash = hash(word);
        strcpy(new_node->word, word);
        if (table[wordHash] == NULL) {
            table[wordHash] = new_node;
        } else {
            new_node->next = table[wordHash];
            table[wordHash] = new_node;
        }
    }
    fclose(dict);
    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    return wordCount;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    node *ptr = NULL;
    for (int i = 0; i < N-1; i++) {
        ptr = table[i];
        node *temp = NULL;
        while(ptr != NULL) {
            temp = ptr->next;
            free(ptr);
            ptr = temp;
        }
    }
    return true;
}
